const STORAGE_KEY = 'wheres-my-car-spot';
const card = document.getElementById('card');

function loadSpot() {
  try { const raw = localStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : null; }
  catch (e) { return null; }
}
function saveSpot(spot) { localStorage.setItem(STORAGE_KEY, JSON.stringify(spot)); }
function clearSpot() { localStorage.removeItem(STORAGE_KEY); }
function fmtTime(ts) {
  const d = new Date(ts);
  return d.toLocaleString(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' });
}
function elapsed(ts) {
  const mins = Math.round((Date.now() - ts) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + ' min ago';
  const hrs = Math.floor(mins / 60);
  const rem = mins % 60;
  return hrs + 'h ' + (rem ? rem + 'm ' : '') + 'ago';
}
function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

function render() {
  const spot = loadSpot();
  if (!spot) {
    card.innerHTML = `
      <div class="status-icon">📍</div>
      <div class="status-text">No parking spot saved yet.<br>Tap "Park Here" once you've parked.</div>
      <input type="text" class="note-input" id="noteInput" placeholder="Note (e.g. Level 3, Row B) — optional">
      <button class="park-btn" id="parkBtn">📍 Park Here</button>
      <div class="error-msg" id="errMsg"></div>
    `;
    document.getElementById('parkBtn').onclick = handlePark;
  } else {
    const mapsUrl = `https://maps.apple.com/?daddr=${spot.lat},${spot.lng}`;
    card.innerHTML = `
      <div class="status-icon">🅿️</div>
      <div class="status-text">Your car is parked here${spot.note ? ':<br><b style="color:var(--text)">' + escapeHtml(spot.note) + '</b>' : '.'}</div>
      <div class="timestamp">Saved ${fmtTime(spot.ts)} · ${elapsed(spot.ts)}</div>
      <div class="coords">${spot.lat.toFixed(5)}, ${spot.lng.toFixed(5)}${spot.accuracy ? ' · ±' + Math.round(spot.accuracy) + 'm' : ''}</div>
      <a href="${mapsUrl}" style="text-decoration:none"><button class="park-btn">🧭 Navigate to Car</button></a>
      <div class="secondary-row">
        <button class="secondary-btn" id="updateBtn">🔄 Update Spot</button>
        <button class="secondary-btn danger" id="clearBtn">🗑️ Clear</button>
      </div>
    `;
    document.getElementById('updateBtn').onclick = handlePark;
    document.getElementById('clearBtn').onclick = () => { clearSpot(); render(); };
  }
}

function handlePark() {
  const noteInput = document.getElementById('noteInput');
  const note = noteInput ? noteInput.value.trim() : (loadSpot()?.note || '');
  const btn = document.getElementById('parkBtn') || document.getElementById('updateBtn');

  if (!('geolocation' in navigator)) {
    const em = document.getElementById('errMsg');
    if (em) em.textContent = "Location isn't available in this browser.";
    return;
  }
  if (btn) { btn.textContent = '📡 Locating…'; btn.classList.add('pulse'); }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      saveSpot({
        lat: pos.coords.latitude, lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy, ts: Date.now(), note: note || ''
      });
      render();
    },
    (err) => {
      let msg = "Couldn't get your location.";
      if (err.code === err.PERMISSION_DENIED) msg = 'Location access denied. Check Safari settings.';
      if (btn) { btn.textContent = '📍 Park Here'; btn.classList.remove('pulse'); }
      const em = document.getElementById('errMsg');
      if (em) em.textContent = msg;
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
  );
}

render();
setInterval(() => { if (loadSpot()) render(); }, 60000);
